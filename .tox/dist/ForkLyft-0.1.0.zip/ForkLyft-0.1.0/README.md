# ForkLyft
Automates AWS Multi-Account CloudFormation Stack Deployments and enforces naming conventions of CloudFormation Stacks.
