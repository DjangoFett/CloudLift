"""All interfaces done through the cli are handled through this"""



def main():
    pass


if __name__ == "__main__":
    main()